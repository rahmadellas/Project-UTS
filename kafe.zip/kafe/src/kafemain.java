
import java.util.Scanner;
        public class kafemain {

            public static void main(String[] args) {
                Scanner input = new Scanner(System.in);
                kafe a = new kafe();
                System.out.println("           Welcome to BLINK Cafe            ");
                System.out.println("============================================");
                System.out.println("Menu : ");
                System.out.println("1. Pasta Agio E Olio IDR 45.000");
                System.out.println("2. Bruschetta IDR 43.000");
                System.out.println("3. Pizza Liumere IDR 70.000");
                System.out.println("4. Burger Cheese + French Fries IDR 35.000");
                System.out.println("5. Donnuts Mini (5 pcs) IDR 24.000");
                System.out.println("============================================");
                System.out.println("Pilih menu Anda: ");
                a.pilihan = input.nextInt();
                if (a.pilihan >= 1 && a.pilihan <= 5) {
                    System.out.println("Masukkan jumlah banyak makanan: ") ;
                    a.jumlah = input.nextInt();
                }

                a.hitungTotal();
                a.viewTotalharga();
                a.hitungKembalian();
            }
    }