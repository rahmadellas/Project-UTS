import java.util.Scanner;
public class kafe {
    double hargamakanan;
    double total;
    double bayar;
    double kembalian;
    double jumlah;
    int pilihan;
    Scanner n = new Scanner(System.in);

    public void hitungTotal() {
        if (pilihan == 1){
            hargamakanan = 45000;
            total = hargamakanan * jumlah;
        }
        else if (pilihan == 2){
            hargamakanan = 43000;
            total = hargamakanan * jumlah;
        }
        else if (pilihan == 3){
            hargamakanan = 70000;
            total = hargamakanan * jumlah;
        }
        else if (pilihan == 4){
            hargamakanan = 35000;
            total = hargamakanan * jumlah;
        }
        else if (pilihan == 5){
            hargamakanan = 24000;
            total = hargamakanan * jumlah;
        }
    }

    public void viewTotalharga() {
        System.out.println("============================================");
        System.out.println("Total harga pesanan: Rp." + total);
        System.out.println("Jumlah uang untuk membayar: ");
        bayar = n.nextInt();
    }

    public void hitungKembalian() {
        kembalian = bayar - total;
        System.out.println("Kembalian: Rp." + kembalian);
    }

}

